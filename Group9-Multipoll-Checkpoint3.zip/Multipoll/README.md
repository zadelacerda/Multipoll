# Multipoll

Android app designed for groups to make decisions through voting. 
