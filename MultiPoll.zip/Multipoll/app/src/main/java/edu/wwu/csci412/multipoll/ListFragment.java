package edu.wwu.csci412.multipoll;

import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.FragmentActivity;

public class ListFragment extends FragmentActivity {
    public void onViewCreated(View view, Bundle savedInstaceState) {

    }
}
