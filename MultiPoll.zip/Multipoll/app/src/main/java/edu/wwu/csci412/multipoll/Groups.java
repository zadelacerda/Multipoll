package edu.wwu.csci412.multipoll;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Groups extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groups);


    }
}
